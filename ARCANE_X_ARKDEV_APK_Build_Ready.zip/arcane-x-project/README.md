# ARCANE X — by ARKDEV

This ZIP includes:
- `index.html` / `web-preview/index.html`: interactive browser preview, custom animated splash screen, ARCANE X/ARKDEV branding, and sample app picker.
- `android-app/`: Kotlin + Jetpack Compose starter with min SDK 26, installed launchable-app picker, launch-on-tap, permission settings shortcuts, shared StateFlow monitor repository, floating-handle service scaffold, and boot receiver scaffold.

## Run the web preview
Open `index.html` in Chrome. The web picker uses sample apps because browsers cannot enumerate installed apps.

## Open Android project
Open `android-app` in Android Studio with JDK 17 and Android SDK 35, allow Gradle sync, then build/run. This is a starter project and has not been verified by an Android build in this environment.

## Monitoring / detection / boosting
The native app can enumerate launchable apps, launch selected packages, read RAM/battery information, and request Usage Access and overlay permission. CPU `/proc/stat`, GPU sysfs and thermal-zone nodes vary by vendor and may be blocked, so unavailable readings should remain `--`. Battery temperature is not necessarily CPU temperature. The repository samples once per second when its service is running, but foreground app detection via UsageStatsManager and shared-flow rendering in every UI component still need production integration.

A normal Android app cannot guarantee arbitrary game FPS, overclock CPU/GPU, control charging bypass, or force touch latency changes. These controls need supported vendor APIs or privileged/root access. The overlay service is a minimal scaffold, not a finished production sidebar. Test foreground-service rules, notification behavior, boot restrictions and permissions on target Android versions before release. The picker uses launcher intent queries rather than broad QUERY_ALL_PACKAGES access.
