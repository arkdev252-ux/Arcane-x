package com.arkdev.arcanex
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.*
class OverlayService:Service(){
 private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate);private var handle:TextView?=null;private var wm:WindowManager?=null
 override fun onCreate(){super.onCreate();startForeground(711,makeNotification());scope.launch{MonitorRepository.sample(applicationContext)};if(Settings.canDrawOverlays(this))attach()}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{if(handle==null&&Settings.canDrawOverlays(this))attach();return START_STICKY}
 private fun makeNotification():Notification{val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel("arcane_x","ARCANE X",NotificationManager.IMPORTANCE_LOW));return if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"arcane_x").setContentTitle("ARCANE X active").setContentText("Game dashboard service running").setSmallIcon(android.R.drawable.ic_menu_compass).build()else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("ARCANE X active").setSmallIcon(android.R.drawable.ic_menu_compass).notification}
 private fun attach(){try{wm=getSystemService(WINDOW_SERVICE) as WindowManager;val v=TextView(this).apply{text="‹  AX";textSize=12f;setTextColor(0xff160d05.toInt());setBackgroundColor(0xffffc107.toInt());setPadding(14,22,14,22);gravity=Gravity.CENTER;setOnClickListener{text="ARCANE X\\nRAM ${MonitorRepository.stats.value.ramPercent?.let{"$it%"}?:"--"}\\nTap to close";setOnClickListener{stopSelf()}}};val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE;val p=WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL};wm?.addView(v,p);handle=v}catch(_:Exception){}}
 override fun onDestroy(){try{handle?.let{wm?.removeView(it)}}catch(_:Exception){};scope.cancel();super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
