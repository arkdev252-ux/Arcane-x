package com.arkdev.arcanex

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

private val Gold = Color(0xFFFFC107); private val Orange = Color(0xFFFF8A30)
private val Bg = Color(0xFF0D0807); private val Card = Color(0xFF1A1020); private val Muted = Color(0xFFA99EAA)
data class LaunchApp(val label:String,val packageName:String,val icon:Drawable)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Gold,secondary=Orange,background=Bg,surface=Card,onPrimary=Bg,onBackground=Color.White,onSurface=Color.White)){ ArcaneApp(this) } }}
}
class ArcaneVm:ViewModel(){
 var page by mutableStateOf("Home");var mode by mutableStateOf("BALANCE");var fps by mutableIntStateOf(60)
 var games by mutableStateOf(listOf<LaunchApp>());var autoBoost by mutableStateOf(false);var bootSidebar by mutableStateOf(false)
}
@Composable fun ArcaneApp(activity:Activity,vm:ArcaneVm=viewModel()){
 var splash by remember{mutableStateOf(true)};var drawer by remember{mutableStateOf(false)}
 var picker by remember{mutableStateOf(false)};var search by remember{mutableStateOf("")}
 var installed by remember{mutableStateOf(emptyList<LaunchApp>())};var checked by remember{mutableStateOf(setOf<String>())}
 LaunchedEffect(Unit){delay(1900);splash=false}
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A1405),Bg)))){
  Column(Modifier.fillMaxSize().padding(16.dp)){
   Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
    IconButton(onClick={drawer=true}){Icon(Icons.Default.Menu,null,tint=Gold)}
    Column(Modifier.weight(1f)){Text("ARCANE X",color=Gold,fontWeight=FontWeight.Black,letterSpacing=2.sp);Text("POWERED BY ARKDEV",fontSize=9.sp,color=Muted,letterSpacing=1.5.sp)}
    Text("PRO ✦",Modifier.clip(CircleShape).background(Brush.horizontalGradient(listOf(Orange,Gold))).padding(horizontal=12.dp,vertical=7.dp),color=Bg,fontWeight=FontWeight.Black,fontSize=10.sp)
   }
   Spacer(Modifier.height(10.dp))
   when(vm.page){
    "Home"->LazyColumn{item{
     Panel("YOUR GAMING COMMAND CENTER"){Text("ARCANE X",fontSize=30.sp,fontWeight=FontWeight.Black,color=Gold);Text("Optimize device · Boost game · Zero lag",color=Muted,fontSize=12.sp);Text("✦ GOLD  ·  ARKDEV",color=Orange,fontSize=10.sp)}
     Panel("STATUS · IDLE / NO GAME RUNNING"){Text("Live Android sensor values are device-dependent.",color=Muted,fontSize=12.sp)}
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("CPU","--",Color.Cyan,Modifier.weight(1f));Stat("GPU","--",Color(0xFF5C9DFF),Modifier.weight(1f))}
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("RAM","--",Color(0xFFC18AFF),Modifier.weight(1f));Stat("TEMP","--°",Gold,Modifier.weight(1f))}
     Panel("TARGET FRAME RATE"){Text("${vm.fps} FPS",fontSize=30.sp,color=Gold,fontWeight=FontWeight.Black);Text("Current mode: ${vm.mode}",color=Muted);Text("Battery: ${battery(activity)}",color=Color(0xFF55E69A))}
     Panel("PERFORMANCE MODE"){Modes(vm)}
     Button(onClick={activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${activity.packageName}")))},Modifier.fillMaxWidth()){Text("PERMISSION — OVERLAY")}
     Text("Developed by ARKDEV · Unavailable sensors remain --, never simulated.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=12.dp))
    }}
    "My Games"->Column{
     Row(verticalAlignment=Alignment.CenterVertically){Text("MY GAMES",fontWeight=FontWeight.Black,letterSpacing=2.sp,modifier=Modifier.weight(1f));Button(onClick={installed=launchableApps(activity);checked=emptySet();search="";picker=true}){Text("+ ADD GAME")}}
     Text("${vm.games.size} selected apps · tap a card to launch",color=Muted,fontSize=11.sp)
     LazyColumn {items(vm.games,key={it.packageName}){app->Row(Modifier.fillMaxWidth().padding(top=10.dp).clip(RoundedCornerShape(16.dp)).background(Card).border(1.dp,Color(0xFF392B3D),RoundedCornerShape(16.dp)).clickable{activity.packageManager.getLaunchIntentForPackage(app.packageName)?.let(activity::startActivity)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Image(app.icon.toBitmap().asImageBitmap(),null,Modifier.size(44.dp));Column(Modifier.weight(1f).padding(horizontal=10.dp)){Text(app.label,fontWeight=FontWeight.Bold);Text("APP SHORTCUT",color=Color.Cyan,fontSize=9.sp)};Icon(Icons.Default.PlayArrow,null,tint=Gold)}}}
    }
    "Engine"->LazyColumn{item{Panel("ENGINE ACTIVE"){Text("Intelligent performance engine · supported device controls only",color=Muted)};Panel("BOOST MODE"){Modes(vm)};Panel("TARGET FRAME RATE"){Row{listOf(60,90,120,144).forEach{f->TextButton(onClick={vm.fps=f},Modifier.weight(1f).border(if(vm.fps==f)2.dp else 1.dp,if(vm.fps==f)Gold else Muted,RoundedCornerShape(10.dp))){Text("$f",color=if(vm.fps==f)Gold else Color.White)}}};Text("Target preference does not guarantee game FPS.",color=Muted,fontSize=10.sp)};Panel("HARDWARE BOOST"){Text("CPU/GPU clock controls generally need vendor or privileged APIs.",color=Muted,fontSize=12.sp)}}}
    else->LazyColumn{item{Panel("PERMISSIONS"){Text("Usage Access detects foreground apps.",color=Muted);Button(onClick={activity.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}){Text("USAGE ACCESS SETTINGS")};Text("Overlay permission",color=Color.White);Button(onClick={activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:${activity.packageName}")))}){Text("OVERLAY SETTINGS")}};Panel("BEHAVIOR"){Setting("Auto Boost on Launch",vm.autoBoost){vm.autoBoost=it};Setting("Start Sidebar on Boot",vm.bootSidebar){vm.bootSidebar=it}};Panel("ABOUT ARCANE X"){Text("Version 0.1.0 · Developer: ARKDEV",color=Gold);Text("Play smoother, win more.",color=Muted)}}}
  }
  if(drawer)Row(Modifier.fillMaxSize().background(Color(0xBB000000))){Column(Modifier.fillMaxHeight().fillMaxWidth(.83f).background(Color(0xFF130D14)).padding(20.dp)){Text("ARCANE X  BETA",color=Gold,fontWeight=FontWeight.Black,fontSize=20.sp);Text("Play smoother, win more",color=Muted);Spacer(Modifier.height(22.dp));listOf("Home","My Games","Engine","Settings").forEach{item->Text(item,Modifier.fillMaxWidth().padding(vertical=6.dp).clip(RoundedCornerShape(12.dp)).background(if(vm.page==item)Color(0xFF3A1520) else Color.Transparent).clickable{vm.page=item;drawer=false}.padding(14.dp),color=if(vm.page==item)Gold else Color.White)};Spacer(Modifier.weight(1f));Text("Bigger FPS\nSmoother gameplay\nLess heat",color=Muted);Text("DEVELOPED BY ARKDEV",color=Gold,fontSize=10.sp)};Spacer(Modifier.fillMaxSize().clickable{drawer=false})}
  if(picker)AlertDialog(onDismissRequest={picker=false},containerColor=Card,title={Text("CHOOSE YOUR APPS",fontWeight=FontWeight.Black)},text={Column(Modifier.fillMaxWidth().heightIn(max=480.dp)){OutlinedTextField(search,{search=it},label={Text("Search installed apps")},singleLine=true);LazyColumn{items(installed.filter{it.label.contains(search,true)}){app->Row(Modifier.fillMaxWidth().clickable{checked=if(app.packageName in checked)checked-app.packageName else checked+app.packageName}.padding(vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Image(app.icon.toBitmap().asImageBitmap(),null,Modifier.size(36.dp));Column(Modifier.weight(1f).padding(horizontal=8.dp)){Text(app.label,fontSize=12.sp);Text(app.packageName,fontSize=9.sp,color=Muted)};Checkbox(app.packageName in checked,{yes->checked=if(yes)checked+app.packageName else checked-app.packageName})}}}},confirmButton={Button(onClick={vm.games=(vm.games+installed.filter{it.packageName in checked}).distinctBy{it.packageName};picker=false;vm.page="My Games"}){Text("ADD SELECTED ✓")}},dismissButton={TextButton(onClick={picker=false}){Text("CANCEL")}})
  AnimatedVisibility(splash){val t=rememberInfiniteTransition(label="splash");val scale by t.animateFloat(.94f,1.06f,infiniteRepeatable(tween(850),RepeatMode.Reverse),label="pulse");Column(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF351A16),Color(0xFF090607)))),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Box(Modifier.size(104.dp).scale(scale).clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(Orange,Gold))),contentAlignment=Alignment.Center){Text("AX",color=Bg,fontSize=38.sp,fontWeight=FontWeight.Black)};Spacer(Modifier.height(22.dp));Text("ARCANE X",fontSize=27.sp,letterSpacing=5.sp,fontWeight=FontWeight.Black);Text("POWERED BY ARKDEV",color=Muted,fontSize=10.sp,letterSpacing=3.sp);Spacer(Modifier.height(26.dp));LinearProgressIndicator(Modifier.width(170.dp).height(3.dp).clip(CircleShape),color=Gold,trackColor=Color(0xFF3C2935));Spacer(Modifier.height(12.dp));Text("INITIALIZING GAME ENGINE",color=Muted,fontSize=10.sp,letterSpacing=2.sp)}}
 }
}
@Composable private fun Panel(title:String,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().padding(bottom=12.dp).clip(RoundedCornerShape(20.dp)).background(Card).border(1.dp,Color(0xFF392B3D),RoundedCornerShape(20.dp)).padding(16.dp)){Text(title,fontSize=11.sp,letterSpacing=1.5.sp,color=Muted,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));content()}}
@Composable private fun Stat(label:String,value:String,color:Color,modifier:Modifier=Modifier){Column(modifier.padding(bottom=10.dp).clip(RoundedCornerShape(17.dp)).background(Card).border(1.dp,Color(0xFF392B3D),RoundedCornerShape(17.dp)).padding(14.dp)){Text(label,color=Muted,fontSize=10.sp,letterSpacing=1.5.sp);Text(value,color=color,fontSize=24.sp,fontWeight=FontWeight.Black);Text("Sensor unavailable",color=Muted,fontSize=9.sp)}}
@Composable private fun Modes(vm:ArcaneVm){Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){listOf("IDLE","BALANCE","PERFORM","EXTREME").forEach{m->TextButton(onClick={vm.mode=m},Modifier.weight(1f).border(if(vm.mode==m)2.dp else 1.dp,if(vm.mode==m)Gold else Color(0xFF392B3D),RoundedCornerShape(10.dp))){Text(m.take(4),color=if(vm.mode==m)Gold else Muted,fontSize=9.sp)}}}}
@Composable private fun Setting(label:String,value:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth().padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f),fontSize=12.sp);Switch(value,onChange)}}
private fun launchableApps(context:Context):List<LaunchApp>{val pm=context.packageManager;val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);@Suppress("DEPRECATION") val result=pm.queryIntentActivities(intent,0);return result.mapNotNull{r->val p=r.activityInfo?.packageName?:return@mapNotNull null;if(p==context.packageName)null else LaunchApp(r.loadLabel(pm).toString(),p,r.loadIcon(pm))}.distinctBy{it.packageName}.sortedBy{it.label.lowercase()}}
private fun Drawable.toBitmap():Bitmap{val b=Bitmap.createBitmap(intrinsicWidth.coerceAtLeast(1),intrinsicHeight.coerceAtLeast(1),Bitmap.Config.ARGB_8888);val c=Canvas(b);setBounds(0,0,c.width,c.height);draw(c);return b}
private fun battery(context:Context):String{val b=context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager;val n=b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);return if(n in 0..100)"$n%" else "--%"}
