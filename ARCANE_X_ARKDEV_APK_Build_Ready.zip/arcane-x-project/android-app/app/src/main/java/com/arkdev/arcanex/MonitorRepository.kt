package com.arkdev.arcanex

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

data class DeviceStats(val cpuPercent:Int?=null,val gpuPercent:Int?=null,val ramPercent:Int?=null,val batteryPercent:Int?=null,val batteryTempC:Float?=null,val cpuTempC:Float?=null,val charging:Boolean=false,val thermalStatus:Int?=null)

/** Shared StateFlow source. Null means the sensor is unavailable, not a fake reading. */
object MonitorRepository {
 private val state=MutableStateFlow(DeviceStats())
 val stats:StateFlow<DeviceStats> = state
 suspend fun sample(context:Context){while(true){state.value=withContext(Dispatchers.IO){read(context.applicationContext)};delay(1000)}}
 private fun read(c:Context):DeviceStats {
  val am=c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager;val mi=ActivityManager.MemoryInfo();am.getMemoryInfo(mi)
  val ram=if(mi.totalMem>0)((1-mi.availMem.toDouble()/mi.totalMem)*100).toInt().coerceIn(0,100)else null
  val i=c.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED));val l=i?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)?:-1;val s=i?.getIntExtra(BatteryManager.EXTRA_SCALE,-1)?:-1
  val b=if(l>=0&&s>0)l*100/s else null;val t=i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Int.MIN_VALUE)?:Int.MIN_VALUE
  val temp=if(t!=Int.MIN_VALUE)t/10f else null;val st=i?.getIntExtra(BatteryManager.EXTRA_STATUS,-1)?:-1
  val thermal=if(Build.VERSION.SDK_INT>=29)(c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else null
  return DeviceStats(readCpu(),readGpu(),ram,b,temp,readCpuTemp(),st==BatteryManager.BATTERY_STATUS_CHARGING||st==BatteryManager.BATTERY_STATUS_FULL,thermal)
 }
 private var previous:LongArray?=null
 @Synchronized private fun readCpu():Int?=try{val v=File("/proc/stat").useLines{it.first().trim().split(Regex("\\\\s+")).drop(1).take(8).map(String::toLong)};val total=v.sum();val idle=v[3]+(v.getOrNull(4)?:0);val old=previous;previous=longArrayOf(total,idle);if(old==null)null else {val dt=total-old[0];if(dt<=0)null else (((dt-(idle-old[1])).toDouble()/dt)*100).toInt().coerceIn(0,100)}}catch(_:Exception){null}
 private fun readGpu():Int?{for(p in listOf("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage","/sys/class/devfreq/gpu/busy","/sys/class/devfreq/13000000.mali/utilization"))try{val n=File(p).readText().trim().removeSuffix("%").toInt();if(n in 0..100)return n}catch(_:Exception){};return null}
 private fun readCpuTemp():Float?=try{File("/sys/class/thermal").listFiles()?.filter{it.name.startsWith("thermal_zone")}?.firstNotNullOfOrNull{z->val n=File(z,"temp").readText().trim().toLongOrNull()?:return@firstNotNullOfOrNull null;when{n in 1..200->n.toFloat();n in 1000..200000->n/1000f;else->null}}}catch(_:Exception){null}
}
