# Build ARCANE X APK on GitHub (Android phone friendly)

1. Extract this ZIP on your phone.
2. Create/sign in to a GitHub account and create a new repository named `arcane-x`.
3. Upload the contents of the extracted `arcane-x-project` folder to the repository (including the hidden `.github` folder and its workflow file). If the phone's upload page hides dot-folders, use GitHub's web upload or a Git client that supports hidden files.
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Select **Build ARCANE X APK** and tap **Run workflow**. You can also push to the `main` branch to trigger it.
6. Wait for the workflow to finish. Open the completed run, scroll to **Artifacts**, and download `ARCANE-X-debug-apk`.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your phone. Android may ask you to allow installs from the browser or file manager you used.

Notes:
- This produces a **debug APK** for testing, not a signed Play Store release.
- The project has not yet been verified by a successful build. If Actions reports an error, open the failed run and share the first relevant error text or screenshot.
- Some dashboard/monitoring controls are scaffolds or placeholders; this APK does not guarantee real FPS gains or full game monitoring.
